// Copyright (c) 2007 Joseph Gauterin
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

// Tests that the swap header include guards work correctly

#include <boost/utility/swap.hpp>
#include <boost/utility/swap.hpp>

