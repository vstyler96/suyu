This directory contains tests related to specific issues.

The names are intended to indicate both the function or condition being tested
and the issue number.

-----
Copyright Beman Dawes 2012
Distributed under the Boost Software License, Version 1.0.
See http://www.boost.org/LICENSE_1_0.txt
