
The format and language of this reference documentation has been greatly influenced by 
the SGI's `Standard Template Library Programmer's Guide`__.

__ https://boost.org/sgi/stl/


.. copyright:: Copyright �  2001-2009 Aleksey Gurtovoy and David Abrahams
   Distributed under the Boost Software License, Version 1.0. (See accompanying
   file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
