---
name: Problem Report
about: Report a bug, something does not work as it supposed to
title: ''
labels: bug
assignees: ''

---

  Thank you for your contributions. Main development of B2 has moved to
  https://github.com/bfgroup/b2
