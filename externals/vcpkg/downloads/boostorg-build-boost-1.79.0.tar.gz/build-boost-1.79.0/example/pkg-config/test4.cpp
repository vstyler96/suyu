// Copyright 2019 Dmitry Arkhipov
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE.txt or copy at
// https://www.bfgroup.xyz/b2/LICENSE.txt)


#if VERSIONED_API < 2
#  error "API is too old"
#endif

int main() {}
