//  Copyright (c) 2014 Rene Rivera
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE.txt or copy at
//  https://www.bfgroup.xyz/b2/LICENSE.txt)
//

#include <iostream>
#include <cstdlib>

int main()
{
    std::cout << "Hi!\n";
    return EXIT_SUCCESS;
}
