/* Copyright 2006 Ilya Sokolov
   Copyright 2006 Vladimir Prus

   Distributed under the Boost Software License, Version 1.0. (See
   accompanying file LICENSE.txt or copy at
   https://www.bfgroup.xyz/b2/LICENSE.txt)
*/

#include <pch.hpp>

int main()
{
  TestClass c(1, 2);
  return 0;
}
