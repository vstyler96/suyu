/*
 * Copyright 1993-2002 Christopher Seiwald and Perforce Software, Inc.
 *
 * This file is part of Jam - see jam.c for Copyright information.
 */
/*
This file is ALSO:
Copyright 2018-2021 Rene Rivera
Distributed under the Boost Software License, Version 1.0.
(See accompanying file LICENSE.txt or copy at https://www.bfgroup.xyz/b2/LICENSE.txt)
*/


#define VERSION_MAJOR 4
#define VERSION_MINOR 7
#define VERSION_PATCH 2
