# Status: stub, just enough to make tests work.
#
# Named os_j to avoid conflicts with standard 'os'. See
# project.py:import for special-casing.
#
# Copyright 2001, 2002, 2003, 2005 Dave Abrahams
# Copyright 2006 Rene Rivera
# Copyright 2003, 2005 Vladimir Prus
# Distributed under the Boost Software License, Version 1.0.
# (See accompanying file LICENSE.txt or https://www.bfgroup.xyz/b2/LICENSE.txt)
import os

import bjam

__OS = bjam.call("peek", [], "OS")[0]

# Return Jam's name of OS to prevent existing code from burning
# when faced with Python naming
def name():
    return __OS


def environ(keys):
    return [os.environ[key] for key in keys if key in os.environ]
