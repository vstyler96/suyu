Copyright 2002 Vladimir Prus 
Distributed under the Boost Software License, Version 1.0. 
(See accompanying file LICENSE_1_0.txt or http://www.boost.org/LICENSE_1_0.txt) 


This test checks for correct properties of generated and used targets.
