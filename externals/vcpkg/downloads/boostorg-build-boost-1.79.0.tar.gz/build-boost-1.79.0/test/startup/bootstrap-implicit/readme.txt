Copyright 2002 Dave Abrahams 
Distributed under the Boost Software License, Version 1.0. 
(See accompanying file LICENSE_1_0.txt or http://www.boost.org/LICENSE_1_0.txt) 

This file is only here so that cvs update -P won't fail to create a directory
