#include <boost/array.hpp>

int main() {
    boost::array<int,5> a{};
}