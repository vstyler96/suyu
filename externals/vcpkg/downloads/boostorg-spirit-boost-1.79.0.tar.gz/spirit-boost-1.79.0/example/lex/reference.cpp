/*=============================================================================
    Copyright (c) 2001-2011 Hartmut Kaiser
    http://spirit.sourceforge.net/

    Distributed under the Boost Software License, Version 1.0. (See accompanying
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
=============================================================================*/
//[reference_lex_includes
#include <boost/spirit/include/lex.hpp>
#include <boost/phoenix/core.hpp>
#include <boost/phoenix/operator.hpp>
#include <iostream>
#include <string>
//]

//[reference_lex_test
//]

int main()
{
    {
        //[reference_lex_using_declarations_char
        //]

        //[reference_lex_char
        //]
    }

    return 0;
}
